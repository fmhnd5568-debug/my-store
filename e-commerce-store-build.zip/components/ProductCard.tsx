"use client"

import { motion } from "framer-motion"
import { ShoppingCart } from "lucide-react"
import { SITE_CONFIG } from "@/config/site"

interface Product {
  id: number
  name: string
  description: string
  price: number
  originalPrice: number
  discount: number
  isApexDeal: boolean
  image: string
  category: string
}

interface ProductCardProps {
  product: Product
  index: number
}

export function ProductCard({ product, index }: ProductCardProps) {
  const handleAddToCart = () => {
    const message = encodeURIComponent(
      `مرحباً، أريد طلب:\n${product.name}\nالسعر: ${product.price.toLocaleString("ar-EG")} ${SITE_CONFIG.currency}`
    )
    window.open(`https://wa.me/${SITE_CONFIG.whatsapp}?text=${message}`, "_blank")
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      whileHover={{ scale: 1.02, y: -5 }}
      className="group relative bg-card rounded-2xl overflow-hidden border border-white/10 backdrop-blur-sm"
    >
      {/* Badge */}
      <div className="absolute top-3 left-3 z-10">
        {product.isApexDeal ? (
          <span className="bg-primary text-white text-xs font-bold px-2 py-1 rounded-lg">
            APEX DEAL {product.discount}%-
          </span>
        ) : (
          <span className="bg-primary text-white text-xs font-bold px-2 py-1 rounded-lg">
            {product.discount}%-
          </span>
        )}
      </div>

      {/* Image */}
      <div className="aspect-square bg-gradient-to-br from-white/10 to-white/5 p-6 flex items-center justify-center overflow-hidden">
        <motion.div
          whileHover={{ scale: 1.1 }}
          transition={{ duration: 0.3 }}
          className="w-full h-full flex items-center justify-center"
        >
          <div className="w-24 h-24 bg-gradient-to-br from-gold/30 to-primary/30 rounded-full flex items-center justify-center">
            <span className="text-4xl">
              {product.category === "electronics" && "💻"}
              {product.category === "perfumes" && "🌸"}
              {product.category === "clothes" && "👔"}
            </span>
          </div>
        </motion.div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <h3 className="font-bold text-white text-sm leading-tight line-clamp-2">
          {product.name}
        </h3>
        <p className="text-muted-foreground text-xs line-clamp-2">
          {product.description}
        </p>

        {/* Price */}
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-lg font-bold text-primary">
              {product.price.toLocaleString("ar-EG")} {SITE_CONFIG.currency}
            </span>
          </div>
          <span className="text-xs text-muted-foreground line-through">
            {product.originalPrice.toLocaleString("ar-EG")} {SITE_CONFIG.currency}
          </span>
        </div>

        {/* Add to Cart Button */}
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleAddToCart}
          className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 transition-colors"
        >
          <ShoppingCart className="w-4 h-4" />
          <span>أضف للسلة</span>
        </motion.button>
      </div>
    </motion.div>
  )
}
