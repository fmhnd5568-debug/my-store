"use client"

import { MessageCircle, Mail } from "lucide-react"
import { SITE_CONFIG } from "@/config/site"

export function Footer() {
  return (
    <footer className="bg-background border-t border-white/10 py-8 mt-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center gap-4">
          {/* Logo */}
          <h2 className="text-xl font-bold">
            <span className="text-gold">APEX</span>{" "}
            <span className="text-gold">ابيكس</span>
          </h2>

          {/* Contact Info */}
          <div className="flex flex-col sm:flex-row items-center gap-4 text-sm">
            <a
              href={`https://wa.me/${SITE_CONFIG.whatsapp}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-muted-foreground hover:text-[#25D366] transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span dir="ltr">+{SITE_CONFIG.whatsapp}</span>
            </a>
            <a
              href={`mailto:${SITE_CONFIG.email}`}
              className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
            >
              <Mail className="w-4 h-4" />
              <span>{SITE_CONFIG.email}</span>
            </a>
          </div>

          {/* Copyright */}
          <p className="text-xs text-muted-foreground">
            © 2026 {SITE_CONFIG.name}. جميع الحقوق محفوظة
          </p>
        </div>
      </div>
    </footer>
  )
}
