"use client"

import { ShoppingCart, MessageCircle, Search } from "lucide-react"
import { SITE_CONFIG } from "@/config/site"

export function Header() {
  const openWhatsApp = () => {
    window.open(`https://wa.me/${SITE_CONFIG.whatsapp}`, "_blank")
  }

  return (
    <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-xl border-b border-white/10">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <h1 className="text-2xl font-bold">
            <span className="text-gold">APEX</span>{" "}
            <span className="text-gold">ابيكس</span>
          </h1>

          {/* Actions */}
          <div className="flex items-center gap-4">
            <button
              onClick={openWhatsApp}
              className="p-2 rounded-full bg-[#25D366] hover:bg-[#20BD5A] transition-colors"
              aria-label="تواصل عبر واتساب"
            >
              <MessageCircle className="w-5 h-5 text-white" />
            </button>
            <button
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors relative"
              aria-label="سلة التسوق"
            >
              <ShoppingCart className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="mt-4 relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <input
            type="text"
            placeholder="ابحث في قمة المنتجات..."
            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pr-12 pl-4 text-white placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
          />
        </div>
      </div>
    </header>
  )
}
