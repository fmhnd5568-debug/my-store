import type { Config } from "tailwindcss"

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        gold: "var(--gold)",
      },
      fontFamily: {
        sans: ["var(--font-cairo)", "Cairo", "sans-serif"],
      },
    },
  },
  plugins: [],
}
export default config
