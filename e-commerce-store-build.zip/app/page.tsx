"use client"

import { motion } from "framer-motion"
import { Flame } from "lucide-react"
import { Header } from "@/components/Header"
import { ProductCard } from "@/components/ProductCard"
import { Footer } from "@/components/Footer"
import { PRODUCTS } from "@/config/site"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto px-4 py-6">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <Flame className="w-6 h-6 text-primary animate-pulse" />
            <h2 className="text-2xl font-bold text-primary">عروض القمة</h2>
            <Flame className="w-6 h-6 text-primary animate-pulse" />
          </div>
          <p className="text-muted-foreground">
            {PRODUCTS.length} منتج في قمة الجودة
          </p>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {PRODUCTS.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      </main>

      <Footer />
    </div>
  )
}
