export const SITE_CONFIG = {
  name: "ابيكس Apex",
  whatsapp: "201217778898",
  email: "info@apex.com",
  currency: "ج.م",
  adminPassword: "apex2026"
}

export const PRODUCTS = [
  {
    id: 1,
    name: "لابتوب ابيكس برو 16 بوصة",
    description: "أداء قمة مع معالج الجيل الأخدث",
    price: 45000,
    originalPrice: 52000,
    discount: 13,
    isApexDeal: true,
    image: "/products/laptop.jpg",
    category: "electronics"
  },
  {
    id: 2,
    name: "سماعة لاسلكية ANC",
    description: "عزل ضوضاء نشط وصوت نقي",
    price: 2800,
    originalPrice: 3500,
    discount: 20,
    isApexDeal: false,
    image: "/products/headphones.jpg",
    category: "electronics"
  },
  {
    id: 3,
    name: "ساعة ذكية ابيكس X",
    description: "تتبع صحي ومكالمات بلوتوث",
    price: 3200,
    originalPrice: 3900,
    discount: 18,
    isApexDeal: false,
    image: "/products/watch.jpg",
    category: "electronics"
  },
  {
    id: 4,
    name: "عطر ابيكس الذهبي 100مل",
    description: "رائحة فاخرة تدوم طويلاً",
    price: 950,
    originalPrice: 1200,
    discount: 21,
    isApexDeal: false,
    image: "/products/perfume.jpg",
    category: "perfumes"
  },
  {
    id: 5,
    name: "قميص قطن مصري",
    description: "خامة ممتازة وقصة عصرية",
    price: 450,
    originalPrice: 550,
    discount: 18,
    isApexDeal: false,
    image: "/products/shirt.jpg",
    category: "clothes"
  },
  {
    id: 6,
    name: "كيبورد ميكانيكي RGB",
    description: "مفاتيح زرقاء للألعاب",
    price: 1850,
    originalPrice: 2200,
    discount: 16,
    isApexDeal: false,
    image: "/products/keyboard.jpg",
    category: "electronics"
  },
  {
    id: 7,
    name: "هاتف ابيكس ماكس 256GB",
    description: "كاميرا 108 ميجابكسل وشاشة AMOLED",
    price: 18500,
    originalPrice: 22000,
    discount: 16,
    isApexDeal: true,
    image: "/products/phone.jpg",
    category: "electronics"
  },
  {
    id: 8,
    name: "تابلت ابيكس تاب 12",
    description: "شاشة 12 بوصة مع قلم ذكي",
    price: 12000,
    originalPrice: 14500,
    discount: 17,
    isApexDeal: false,
    image: "/products/tablet.jpg",
    category: "electronics"
  },
  {
    id: 9,
    name: "عطر أود العربي الفاخر",
    description: "مزيج من العود والمسك الأصيل",
    price: 1500,
    originalPrice: 1850,
    discount: 19,
    isApexDeal: false,
    image: "/products/oud.jpg",
    category: "perfumes"
  },
  {
    id: 10,
    name: "جاكيت جلد طبيعي",
    description: "جلد إيطالي أصلي بتصميم كلاسيكي",
    price: 2800,
    originalPrice: 3400,
    discount: 18,
    isApexDeal: false,
    image: "/products/jacket.jpg",
    category: "clothes"
  },
  {
    id: 11,
    name: "ماوس جيمنج لاسلكي",
    description: "25000 DPI مع إضاءة RGB",
    price: 950,
    originalPrice: 1150,
    discount: 17,
    isApexDeal: false,
    image: "/products/mouse.jpg",
    category: "electronics"
  },
  {
    id: 12,
    name: "شاحن لاسلكي سريع 50W",
    description: "شحن MagSafe لجميع الأجهزة",
    price: 650,
    originalPrice: 800,
    discount: 19,
    isApexDeal: false,
    image: "/products/charger.jpg",
    category: "electronics"
  },
  {
    id: 13,
    name: "عطر ابيكس سيلفر للرجال",
    description: "انتعاش يدوم طوال اليوم",
    price: 750,
    originalPrice: 900,
    discount: 17,
    isApexDeal: false,
    image: "/products/silver-perfume.jpg",
    category: "perfumes"
  },
  {
    id: 14,
    name: "بنطلون جينز سليم فيت",
    description: "قماش مرن ومريح",
    price: 550,
    originalPrice: 680,
    discount: 19,
    isApexDeal: false,
    image: "/products/jeans.jpg",
    category: "clothes"
  },
  {
    id: 15,
    name: "سماعات أذن برو TWS",
    description: "صوت محيطي 360 درجة",
    price: 1200,
    originalPrice: 1450,
    discount: 17,
    isApexDeal: true,
    image: "/products/earbuds.jpg",
    category: "electronics"
  },
  {
    id: 16,
    name: "باور بانك 30000mAh",
    description: "شحن سريع لثلاث أجهزة",
    price: 850,
    originalPrice: 1050,
    discount: 19,
    isApexDeal: false,
    image: "/products/powerbank.jpg",
    category: "electronics"
  },
  {
    id: 17,
    name: "عطر روز الملكي للنساء",
    description: "مزيج الورد الطائفي والعنبر",
    price: 1100,
    originalPrice: 1350,
    discount: 19,
    isApexDeal: false,
    image: "/products/rose-perfume.jpg",
    category: "perfumes"
  },
  {
    id: 18,
    name: "حذاء رياضي ابيكس اير",
    description: "نعل مريح للجري والتمارين",
    price: 1200,
    originalPrice: 1500,
    discount: 20,
    isApexDeal: false,
    image: "/products/shoes.jpg",
    category: "clothes"
  },
  {
    id: 19,
    name: "كاميرا ويب 4K",
    description: "للبث والاجتماعات بجودة فائقة",
    price: 1650,
    originalPrice: 2000,
    discount: 18,
    isApexDeal: false,
    image: "/products/webcam.jpg",
    category: "electronics"
  },
  {
    id: 20,
    name: "طقم عطور ابيكس 3 قطع",
    description: "مجموعة متنوعة للمناسبات",
    price: 1800,
    originalPrice: 2200,
    discount: 18,
    isApexDeal: true,
    image: "/products/perfume-set.jpg",
    category: "perfumes"
  },
  {
    id: 21,
    name: "قميص بولو كلاسيكي",
    description: "قطن 100% بألوان متعددة",
    price: 380,
    originalPrice: 480,
    discount: 21,
    isApexDeal: false,
    image: "/products/polo.jpg",
    category: "clothes"
  },
  {
    id: 22,
    name: "سبيكر بلوتوث مقاوم للماء",
    description: "صوت قوي 40W مع إضاءة",
    price: 1100,
    originalPrice: 1350,
    discount: 19,
    isApexDeal: false,
    image: "/products/speaker.jpg",
    category: "electronics"
  }
]
